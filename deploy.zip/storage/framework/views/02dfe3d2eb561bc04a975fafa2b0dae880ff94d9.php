<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="icon" href="/otrs/favicon.ico">
    <title>ОТРС</title>
    <link href="/otrs/css/chunk-032dfd17.a03fd33b.css" rel="prefetch">
    <link href="/otrs/css/chunk-0d9bd144.f703b1ec.css" rel="prefetch">
    <link href="/otrs/css/chunk-2848ec90.96bd9ffa.css" rel="prefetch">
    <link href="/otrs/css/chunk-2e01d089.1d05f491.css" rel="prefetch">
    <link href="/otrs/css/chunk-30cf7b1c.a7d7323d.css" rel="prefetch">
    <link href="/otrs/css/chunk-3f8d76ac.8fa412b1.css" rel="prefetch">
    <link href="/otrs/css/chunk-420f4fce.1d05f491.css" rel="prefetch">
    <link href="/otrs/css/chunk-570f06e4.1d05f491.css" rel="prefetch">
    <link href="/otrs/css/chunk-733a932e.715daca4.css" rel="prefetch">
    <link href="/otrs/css/chunk-83a3da3e.940d9fdc.css" rel="prefetch">
    <link href="/otrs/js/chunk-032dfd17.d0b6a0d3.js" rel="prefetch">
    <link href="/otrs/js/chunk-05867a20.5ea38f63.js" rel="prefetch">
    <link href="/otrs/js/chunk-0d9bd144.6a718783.js" rel="prefetch">
    <link href="/otrs/js/chunk-2848ec90.18124ae7.js" rel="prefetch">
    <link href="/otrs/js/chunk-2d0aecad.88e1aa31.js" rel="prefetch">
    <link href="/otrs/js/chunk-2d0b19bc.512001da.js" rel="prefetch">
    <link href="/otrs/js/chunk-2d0b2035.ce987984.js" rel="prefetch">
    <link href="/otrs/js/chunk-2d0d07a7.81cdb872.js" rel="prefetch">
    <link href="/otrs/js/chunk-2d0ea160.39732606.js" rel="prefetch">
    <link href="/otrs/js/chunk-2d20edd0.4ca7f523.js" rel="prefetch">
    <link href="/otrs/js/chunk-2e01d089.3f2762a0.js" rel="prefetch">
    <link href="/otrs/js/chunk-30cf7b1c.5f865ae6.js" rel="prefetch">
    <link href="/otrs/js/chunk-38256a02.5c77ab15.js" rel="prefetch">
    <link href="/otrs/js/chunk-3f8d76ac.005b0aac.js" rel="prefetch">
    <link href="/otrs/js/chunk-420f4fce.6984d30d.js" rel="prefetch">
    <link href="/otrs/js/chunk-570f06e4.913ef21d.js" rel="prefetch">
    <link href="/otrs/js/chunk-733a932e.17d3bfbe.js" rel="prefetch">
    <link href="/otrs/js/chunk-83a3da3e.b26aaeeb.js" rel="prefetch">
    <link href="/otrs/js/chunk-9a8ed0d2.2ff8c520.js" rel="prefetch">
    <link href="/otrs/css/chunk-vendors.de7737e8.css" rel="preload" as="style">
    <link href="/otrs/css/index.ff2e18fb.css" rel="preload" as="style">
    <link href="/otrs/js/chunk-vendors.0b9e8831.js" rel="preload" as="script">
    <link href="/otrs/js/index.8b85e9e3.js" rel="preload" as="script">
    <link href="/otrs/css/chunk-vendors.de7737e8.css" rel="stylesheet">
    <link href="/otrs/css/index.ff2e18fb.css" rel="stylesheet">

    <link href="/local/front/dist/css/chunk-04ee4d4e.e6c33c80.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-0b065d41.ecfa0938.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-10cfc4bd.bb37fd12.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-117bb523.0547d5b3.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-1daa2f12.2b72192c.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-281d06eb.c1cac3c5.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-44003630.ebcb3a8c.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-4ad43c0f.3b43bcb8.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-4e0764d4.219a36ba.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-53bea088.3006eacc.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-551caf28.b8778cc6.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-5b1b9d17.73c24c59.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-6089d41e.89bbf625.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-6c0cd7d3.b94f9af0.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-7e025445.053693fb.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-902c738e.d01c228e.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-ab81552c.897aa8c4.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-b7a244ac.a5b24309.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-befc69aa.62241fb8.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-c04f4b16.7e2937b5.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-fdf2b876.ae9dce94.css" rel="prefetch">
    <link href="/local/front/dist/js/chunk-04ee4d4e.6a1a4b45.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-0b065d41.bc6472b8.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-10cfc4bd.efd209d4.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-117bb523.184fcdbb.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-1daa2f12.c53f6c76.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-281d06eb.da86af56.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d0e2373.2aad24a6.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d21a378.d6c77ddb.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d237b43.0aa5785d.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-44003630.befa9bb4.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-4ad43c0f.c12a60d3.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-4e0764d4.9834bee7.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-53bea088.e167f15e.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-551caf28.7781de14.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-5b1b9d17.61306048.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-6089d41e.0fbf1709.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-6c0cd7d3.38616b9b.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-7e025445.d8dc1f35.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-902c738e.86618373.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-ab81552c.fb2f9cdc.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-b7a244ac.ef6b8f1a.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-befc69aa.e944f211.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-c04f4b16.993abcdb.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-fdf2b876.b73f3b50.js" rel="prefetch">
    <link href="/local/front/dist/css/chunk-vendors.eb45f3a7.css" rel="preload" as="style">
    <link href="/local/front/dist/css/index.6dd641c0.css" rel="preload" as="style">
    <link href="/local/front/dist/js/chunk-vendors.9917ac31.js" rel="preload" as="script">
    <link href="/local/front/dist/js/index.2fa640a4.js" rel="preload" as="script">
    <link href="/local/front/dist/css/chunk-vendors.eb45f3a7.css" rel="stylesheet">
    <link href="/local/front/dist/css/index.6dd641c0.css" rel="stylesheet">
</head>
<body>
<noscript><strong>We're sorry but ОТРС doesn't work properly without JavaScript enabled. Please enable it to
        continue.</strong></noscript>
<div id='bitrix-vue-header'>
    <component is="Header" bitrix-header>
        <template #breadcrumbs>
            <div class="breadcrumb text-xs"><ul class="breadcrumb__list"><li class="breadcrumb__item"><a href="/" class="breadcrumb__link">Главная</a></li><li class="breadcrumb__item">Субсидии</li></ul></div>
        </template>
    </component>
</div>
<div id="app"></div>
<div id="bitrix-vue-footer"></div>
<script src="/otrs/js/chunk-vendors.0b9e8831.js"></script>
<script src="/otrs/js/index.8b85e9e3.js"></script>

<script src="/local/front/dist/js/chunk-vendors.9917ac31.js"></script>
<script src="/local/front/dist/js/index.2fa640a4.js"></script>
</body>
</html>
<?php /**PATH /home/rydal/Projects/techno-park/backend/resources/views/otrs.blade.php ENDPATH**/ ?>