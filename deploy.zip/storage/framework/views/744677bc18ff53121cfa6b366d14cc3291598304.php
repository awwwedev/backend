<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="icon" href="/spa/loan/dist/favicon.ico">
    <title>concessional-lending-frontend</title>
    <link href="/spa/loan/dist/css/chunk-0fb0fccf.57f0988f.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-1976dd23.adbcd62d.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-38dfb9a2.9b336c50.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-5780c90a.5be18a26.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-5d9d41e0.4ff28e9a.css" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-0fb0fccf.4980ea51.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-1976dd23.4f743929.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-38dfb9a2.f44f58d7.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-5780c90a.f14eb54f.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-5d9d41e0.b2f76fb5.js" rel="prefetch">
    <link href="/spa/loan/dist/css/app.1b217934.css" rel="preload" as="style">
    <link href="/spa/loan/dist/css/chunk-vendors.37825080.css" rel="preload" as="style">
    <link href="/spa/loan/dist/js/app.c2b64a00.js" rel="preload" as="script">
    <link href="/spa/loan/dist/js/chunk-vendors.a460feff.js" rel="preload" as="script">
    <link href="/spa/loan/dist/css/chunk-vendors.37825080.css" rel="stylesheet">
    <link href="/spa/loan/dist/css/app.1b217934.css" rel="stylesheet">
</head>
<body>
<noscript><strong>We're sorry but concessional-lending-frontend doesn't work properly without JavaScript enabled. Please
        enable it to continue.</strong></noscript>
<div id="loan"></div>
<script src="/spa/loan/dist/js/chunk-vendors.a460feff.js"></script>
<script src="/spa/loan/dist/js/app.c2b64a00.js"></script>
</body>
</html>
<?php /**PATH /home/rydal/Projects/techno-park/backend/resources/views/test.blade.php ENDPATH**/ ?>