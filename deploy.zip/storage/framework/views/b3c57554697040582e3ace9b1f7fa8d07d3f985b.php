<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="icon" href="/spa/loan/dist/favicon.ico">
    <title>concessional-lending-frontend</title>
    <link href="/spa/loan/dist/css/chunk-0fb0fccf.57f0988f.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-1976dd23.adbcd62d.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-38dfb9a2.9b336c50.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-5780c90a.5be18a26.css" rel="prefetch">
    <link href="/spa/loan/dist/css/chunk-5d9d41e0.4ff28e9a.css" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-0fb0fccf.4980ea51.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-1976dd23.4f743929.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-38dfb9a2.f44f58d7.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-5780c90a.f14eb54f.js" rel="prefetch">
    <link href="/spa/loan/dist/js/chunk-5d9d41e0.b2f76fb5.js" rel="prefetch">
    <link href="/spa/loan/dist/css/app.1b217934.css" rel="preload" as="style">
    <link href="/spa/loan/dist/css/chunk-vendors.37825080.css" rel="preload" as="style">
    <link href="/spa/loan/dist/js/app.c2b64a00.js" rel="preload" as="script">
    <link href="/spa/loan/dist/js/chunk-vendors.a460feff.js" rel="preload" as="script">
    <link href="/spa/loan/dist/css/chunk-vendors.37825080.css" rel="stylesheet">
    <link href="/spa/loan/dist/css/app.1b217934.css" rel="stylesheet">

    <link href="/local/front/dist/css/chunk-0f1ce2a0.94288de9.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-12755a2e.aaec8305.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-1955a400.a71e9765.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-281a0de3.c730b345.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-381da862.52f841fd.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-3a8f745c.dccbfc9d.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-41ed5dfa.aa5aa388.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-54dc47a6.82a883ef.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-5931c233.18876280.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-5b1b9d17.ddf69a48.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-68d8c5f8.906c70a0.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-76617004.669fb6a9.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-78a52683.ab350549.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-7e7aec4d.bf48b988.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-7ffe4b94.868711c2.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-8afc6940.a005a0c5.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-8fa1764c.0b9ea935.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-968129e2.234cc20a.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-ce7c4ed4.94f3e635.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-cf6d343c.1bcf399d.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-eb2ea0be.7eabb2b2.css" rel="prefetch">
    <link href="/local/front/dist/css/chunk-f99e46de.9aa5eda9.css" rel="prefetch">
    <link href="/local/front/dist/js/chunk-0f1ce2a0.109c443e.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-12755a2e.70459917.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-1955a400.10e552f1.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-1f45cd05.3d1280c8.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-281a0de3.11b03d35.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d0a4108.4316f65f.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d0aece6.b6871097.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d0c160f.d23c4f1a.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d0e2373.06188e3d.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d0e5586.322a9909.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d21eeed.26296d8c.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-2d237b43.b6250dab.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-381da862.7cad97f4.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-3a8f745c.d1d13a8f.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-41ed5dfa.e41e9ba9.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-4205ef78.3b4f7811.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-54dc47a6.debfff28.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-5931c233.7c9267bc.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-5b1b9d17.1126b9f5.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-6257766e.9811ed86.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-68d8c5f8.0810bb3c.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-76617004.a39007af.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-78a52683.b5fdd28b.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-7e7aec4d.7e9463fd.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-7ffe4b94.5638d12b.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-8afc6940.3e372ffd.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-8fa1764c.7aa5c104.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-915e2c54.c2fc884f.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-968129e2.abc86e91.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-ce7c4ed4.8267996a.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-cf6d343c.71fc62d2.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-eb2ea0be.daed79ac.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-ee7bc7ea.0378051b.js" rel="prefetch">
    <link href="/local/front/dist/js/chunk-f99e46de.bb56da26.js" rel="prefetch">
    <link href="/local/front/dist/css/chunk-vendors.eb45f3a7.css" rel="preload" as="style">
    <link href="/local/front/dist/css/index.a1308c1d.css" rel="preload" as="style">
    <link href="/local/front/dist/js/chunk-vendors.1ccd8e04.js" rel="preload" as="script">
    <link href="/local/front/dist/js/index.a8815532.js" rel="preload" as="script">
    <link href="/local/front/dist/css/chunk-vendors.eb45f3a7.css" rel="stylesheet">
    <link href="/local/front/dist/css/index.a1308c1d.css" rel="stylesheet">
</head>
<body>
<noscript><strong>We're sorry but concessional-lending-frontend doesn't work properly without JavaScript enabled. Please
        enable it to continue.</strong></noscript>
<div id='bitrix-vue-header'>
    <component is="Header" bitrix-header>
    </component>
</div>
<div class='MainSection'>
    <div class='container'>
        <h1 class="header__title">Новости</h1>
    </div>
</div>
<div id="loan"></div>
<div id="bitrix-vue-footer"></div>
<script src="/local/front/dist/js/chunk-vendors.1ccd8e04.js"></script>
<script src="/local/front/dist/js/index.a8815532.js"></script>

<script src="/spa/loan/dist/js/chunk-vendors.a460feff.js"></script>
<script src="/spa/loan/dist/js/app.c2b64a00.js"></script>
</body>
</html>
<?php /**PATH /home/rydal/Projects/techno-park/backend/resources/views/loan.blade.php ENDPATH**/ ?>